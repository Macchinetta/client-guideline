/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// selectmenu.js

'use strict';

$(function () {
  $('#selectmenu').selectmenu({
    width: 200
  });
});
