/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// datepicker-basic.js

'use strict';

// シンプルなカレンダー
$(function () {

  // テキストフィールドに対し、datepickerメソッドを実行する。
  $('#jquery-ui-datepicker').datepicker();
});
