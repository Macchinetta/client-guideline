/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// tabs.js

'use strict';

$(function () {

  // tabsメソッドを実行する
  $('#tabs').tabs({
  });
});