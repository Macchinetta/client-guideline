/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// accordion-basic.js

'use strict';

// 基本的なアコーディオン
$(function () {
  $('#accordion').accordion({
  });
});
