/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// slider.js

'use strict';

$(function () {

  // sliderメソッドを実行する。
  $('#slider').slider({
  });
});