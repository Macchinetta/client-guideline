/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// default.js

'use strict';

$(function () {
  $('.table').tablesorter({

    // tablesorterの動作オプション
  });
});