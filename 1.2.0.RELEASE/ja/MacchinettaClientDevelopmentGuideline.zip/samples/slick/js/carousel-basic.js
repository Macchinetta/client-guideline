/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// carousel-basic.js

'use strict';

$(function () {
  $('.carousel-basic').slick({
    dots: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000
  });
});

