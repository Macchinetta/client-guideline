/*
 *
 * Copyright(c) 2018 NTT Corporation.
 */
// carousel-center.js

'use strict';

$(function () {
  $('.carousel-center').slick({
    dots: true,
    centerMode: true,
    slidesToShow: 3
  });
});

