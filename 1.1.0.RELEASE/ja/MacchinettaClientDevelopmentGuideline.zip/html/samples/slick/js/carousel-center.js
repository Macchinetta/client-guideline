// carousel-center.js

'use strict';

$(function () {
  $('.carousel-center').slick({
    dots: true,
    centerMode: true,
    slidesToShow: 3
  });
});

