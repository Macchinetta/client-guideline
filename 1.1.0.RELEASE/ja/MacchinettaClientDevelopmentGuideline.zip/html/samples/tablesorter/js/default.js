// default.js

'use strict';

$(function () {
  $('.table').tablesorter({

    // tablesorterの動作オプション
  });
});