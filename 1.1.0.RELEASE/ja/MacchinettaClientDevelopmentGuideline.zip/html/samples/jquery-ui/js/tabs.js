// tabs.js

'use strict';

$(function () {

  // tabsメソッドを実行する
  $('#tabs').tabs({
  });
});