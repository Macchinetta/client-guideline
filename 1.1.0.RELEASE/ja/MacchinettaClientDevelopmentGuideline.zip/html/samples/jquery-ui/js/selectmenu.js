// selectmenu.js

'use strict';

$(function () {
  $('#selectmenu').selectmenu({
    width: 200
  });
});
