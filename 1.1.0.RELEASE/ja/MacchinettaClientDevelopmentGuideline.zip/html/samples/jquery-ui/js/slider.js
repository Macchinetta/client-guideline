// slider.js

'use strict';

$(function () {

  // sliderメソッドを実行する。
  $('#slider').slider({
  });
});