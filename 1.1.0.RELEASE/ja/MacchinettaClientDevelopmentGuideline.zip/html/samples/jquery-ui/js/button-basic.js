// button-basic.js

'use strict';

// ボタンを生成する対象に対して、buttonメソッドを実行する
$(function () {
  $('.buttonClass').button({
  });
});
