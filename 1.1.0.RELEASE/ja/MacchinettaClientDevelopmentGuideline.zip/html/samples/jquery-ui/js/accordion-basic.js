// accordion-basic.js

'use strict';

// 基本的なアコーディオン
$(function () {
  $('#accordion').accordion({
  });
});
