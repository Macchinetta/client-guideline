// button-buttonset.js

'use strict';

// ボタンを生成する対象のグループに対して、buttonsetメソッドを実行する
$(function () {
  $('.buttonset').buttonset({
  });
});
